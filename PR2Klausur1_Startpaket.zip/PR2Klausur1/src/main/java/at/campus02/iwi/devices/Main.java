package at.campus02.iwi.devices;

public class Main {
    public static void main(String[] args) {
        // you can test your stuff however you like - it is not evaluated
    }
}
